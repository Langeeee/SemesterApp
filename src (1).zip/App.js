import React, { useEffect, useState, useCallback } from "react";
import NetInfo from "@react-native-community/netinfo";
import { MaterialIcons } from "@expo/vector-icons";
import * as SplashScreen from "expo-splash-screen";
import { ifIphoneX } from "react-native-iphone-x-helper";
import {
  StyleSheet,
  Text,
  View,
  ActivityIndicator,
  BackHandler,
  Alert,
  Image,
  TouchableOpacity,
  StatusBar,
  Platform,
  ToastAndroid,
} from "react-native";
import { WebView } from "react-native-webview";

export default function App() {
  const [showError, setShowError] = useState(false);
  const [checkNet, setCheckNet] = useState(true);
  const [loading, setLoading] = useState(false);
  const [canGoBack, setCanGoBack] = useState(false);
  const [exitURL, setExitURL] = useState("");
  const [key, setKey] = useState(0);
  const webviewRef = React.useRef(null);
  const STATUSBAR_HEIGHT = StatusBar.currentHeight;
  const [appIsReady, setAppIsReady] = useState(false);
  let exitApp = 0;
  const backButtonHandler = () => {
    setTimeout(() => {
      // setExitApp(0);
      exitApp = 0;
      console.log(exitApp);
    }, 300); // 2 seconds to tap second-time
    if (exitApp === 0) {
      // setExitApp(exitApp + 1);
      exitApp = 1;
      console.log("increment", exitApp);

      if (webviewRef.current) webviewRef.current.goBack();
    } else if (exitApp === 1) {
      Alert.alert("Hold on!", "Are you sure you want to exit?", [
        {
          text: "Cancel",
          onPress: () => null,
          style: "cancel",
        },
        { text: "YES", onPress: () => BackHandler.exitApp() },
      ]);
      return true;
    }
    return true;
  };

  useEffect(() => {
    // NetInfo.fetch().then((state) => {
    //   console.log("Connection type", state.type);
    //   console.log("Is connected?", state.isConnected);
    // });
    const unsubscribe = NetInfo.addEventListener((state) => {
      setCheckNet(state.isConnected);
      console.log("Connection type", state.type);
      console.log("Is connected?", state.isConnected);
    });

    BackHandler.addEventListener("hardwareBackPress", backButtonHandler);

    return () => {
      unsubscribe();
    };
  }, [canGoBack]);

  const NoInternet = () => {
    setLoading(false);
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
        <Image
          source={require("./assets/disconnect.png")}
          style={{ width: 100, height: 100, tintColor: "#68e8c6" }}
        />
        <Text style={{ fontSize: 18, fontWeight: "bold", color: "#68e8c6" }}>
          No Internet Connection
        </Text>
        <TouchableOpacity
          onPress={() => {
            setKey((prevKey) => prevKey + 1);
          }}
        >
          <Text
            style={{
              backgroundColor: "#68e8c6",
              color: "white",
              paddingHorizontal: 20,
              paddingVertical: 8,
              borderRadius: 5,
              top: 15,
            }}
          >
            Retry
          </Text>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      {loading === true ? (
        <View
          style={{
            flex: 1,
            top: StatusBar.currentHeight || 50,
            alignSelf: "center",
            position: "absolute",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 99,
          }}
        >
          <ActivityIndicator size={"large"} color="#2d2c71" />
        </View>
      ) : null}
      <View style={styles.webviewContainer}>
        {checkNet == false ? (
          <NoInternet />
        ) : (
          <>
            {Platform.OS == "ios" ? (
              <StatusBar translucent barStyle={"dark-content"} />
            ) : (
              <StatusBar translucent />
            )}

            <WebView
              //  userAgent="Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko"
              userAgent={
                Platform.OS == "ios"
                  ? `Mozilla/5.0 (iPhone; CPU iPhone OS 14_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1 Mobile/15E148 Safari/604.1`
                  : `Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.91 Mobile Safari/537.36`
              }
              ref={webviewRef}
              onLoadStart={() => {
                console.log("Loading Started");
                setLoading(true);
              }}
              onLoad={() => {
                console.log("Loading Finished");
                setLoading(false);
              }}
              source={{ uri: "https://theq.dk" }}
              originWhitelist={["*"]}
              javaScriptEnabled={true}
              onNavigationStateChange={(navState) => {
                setCanGoBack(navState.canGoBack);
                console.log("Web Can Go Bacl ?", navState.canGoBack);
              }}
              //onLoadStart={() => setLoading(true)}

              onError={({ nativeEvent }) => setCheckNet(false)}
              renderError={() => {
                () => <NoInternet />;
              }}
              key={key}
            />
          </>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,

    backgroundColor: "#fff",
  },
  webviewContainer: {
    marginTop: Platform.OS == "ios" ? 20 : 35,
    ...ifIphoneX({
      marginTop: 38,
    }),

    flex: 1,
  },
});
const renderError = () => {
  return <Text> Error : Check Internet Connection</Text>;
};
